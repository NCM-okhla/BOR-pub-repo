package com.bor.rcms.security;

public class JwtAuthenticationEntryPoint {

}
