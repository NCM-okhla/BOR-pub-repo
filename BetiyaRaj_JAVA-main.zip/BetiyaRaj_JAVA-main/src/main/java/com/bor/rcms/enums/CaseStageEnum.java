//package com.bor.rcms.enums;
//
//public enum CaseStageEnum {
//    FILED, 
//    HEARING, 
//    APPEAL_TO_COLLECTOR, 
//    APPEAL_TO_DIVISIONAL_COMMISSIONER, 
//    FINAL_DECISION
//}
