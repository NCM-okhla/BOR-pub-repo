package com.bor.rcms.dto;

public class FreeHoldIntiate {
	 private String name;
	    private String address;
	    private String phone;
	    private String gender;
	    private String district;
	    private String circle;
	    private String halka;
	    private String mauja;
	    private String khata;
	    private String plot;
	    private String acre;
	    private String acreUnit;
	    private String dismil;
	    private String dismilUnit;
	    private String admissionDate;
	    private String admissionTime;
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		public String getPhone() {
			return phone;
		}
		public void setPhone(String phone) {
			this.phone = phone;
		}
		public String getGender() {
			return gender;
		}
		public void setGender(String gender) {
			this.gender = gender;
		}
		public String getDistrict() {
			return district;
		}
		public void setDistrict(String district) {
			this.district = district;
		}
		public String getCircle() {
			return circle;
		}
		public void setCircle(String circle) {
			this.circle = circle;
		}
		public String getHalka() {
			return halka;
		}
		public void setHalka(String halka) {
			this.halka = halka;
		}
		public String getMauja() {
			return mauja;
		}
		public void setMauja(String mauja) {
			this.mauja = mauja;
		}
		public String getKhata() {
			return khata;
		}
		public void setKhata(String khata) {
			this.khata = khata;
		}
		public String getPlot() {
			return plot;
		}
		public void setPlot(String plot) {
			this.plot = plot;
		}
		public String getAcre() {
			return acre;
		}
		public void setAcre(String acre) {
			this.acre = acre;
		}
		public String getAcreUnit() {
			return acreUnit;
		}
		public void setAcreUnit(String acreUnit) {
			this.acreUnit = acreUnit;
		}
		public String getDismil() {
			return dismil;
		}
		public void setDismil(String dismil) {
			this.dismil = dismil;
		}
		public String getDismilUnit() {
			return dismilUnit;
		}
		public void setDismilUnit(String dismilUnit) {
			this.dismilUnit = dismilUnit;
		}
		public String getAdmissionDate() {
			return admissionDate;
		}
		public void setAdmissionDate(String admissionDate) {
			this.admissionDate = admissionDate;
		}
		public String getAdmissionTime() {
			return admissionTime;
		}
		public void setAdmissionTime(String admissionTime) {
			this.admissionTime = admissionTime;
		}
		@Override
		public String toString() {
			return "FreeHoldIntiate [name=" + name + ", address=" + address + ", phone=" + phone + ", gender=" + gender
					+ ", district=" + district + ", circle=" + circle + ", halka=" + halka + ", mauja=" + mauja
					+ ", khata=" + khata + ", plot=" + plot + ", acre=" + acre + ", acreUnit=" + acreUnit + ", dismil="
					+ dismil + ", dismilUnit=" + dismilUnit + ", admissionDate=" + admissionDate + ", admissionTime="
					+ admissionTime + "]";
		}
		public FreeHoldIntiate() {
			super();
			// TODO Auto-generated constructor stub
		}
	    

}
