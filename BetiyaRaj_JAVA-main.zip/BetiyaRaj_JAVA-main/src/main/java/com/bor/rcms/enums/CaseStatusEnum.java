//package com.bor.rcms.enums;
//
//public enum CaseStatusEnum {
//    APPEAL, 
//    COLLECTOR_PENDING, 
//    HEARING_PENDING, 
//    APPROVED, 
//    REJECTED, 
//    CLOSED
//}
