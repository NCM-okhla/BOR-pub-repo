package com.bor.rcms.entity;

public class OcccpantDetails {

}
