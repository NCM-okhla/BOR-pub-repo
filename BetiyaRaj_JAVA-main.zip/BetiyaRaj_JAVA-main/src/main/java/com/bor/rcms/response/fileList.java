package com.bor.rcms.response;

import java.util.List;

import com.bor.rcms.entity.DocumentEntity;

public class fileList {
private List<DocumentEntity> docemnt;



}
