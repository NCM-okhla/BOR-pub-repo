package com.bor.rcms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RcmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
